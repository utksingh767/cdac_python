def myfun1():     # memory allocation happens here for the function
    print("First")
    print("Second")
    print("Third")
myfun1()

print(type(myfun1))
print(id(myfun1))