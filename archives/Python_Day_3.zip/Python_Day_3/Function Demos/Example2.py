# String concatenation

def myfun():
    num1=100
    print("Value of Num is\t"+str(num1))
    print("Value of Num is\t",num1)
myfun()
print("Done")

print(type(print))
print(id(print))