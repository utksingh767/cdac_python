# sort the list in ascending and descending order

mylist = [23,12,6,8,11,9,13]
print(mylist)
mylist.sort()
print(mylist)
mylist.sort(reverse=True)
print(mylist)
