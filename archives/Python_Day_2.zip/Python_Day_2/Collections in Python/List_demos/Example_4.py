# append and insert methods of list
mylist = [10,20,30,40]

print(mylist)

mylist.append(90)
mylist.insert(2,"welcome")

print(mylist)