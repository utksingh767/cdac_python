# use of extend method to add multiple values at the end of the list

mylist = [10,"hello",4.5,False]

print(mylist)
mylist.extend([20,True,"welcome"])
print(mylist)