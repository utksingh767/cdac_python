# slicing a string

mystring = "Computers"
print(mystring)
print(mystring[2:6])  # slice from 2nd position to 6th position
print(mystring[4:-2]) # slice from 4th position to second last position
