# accessing string by characters

mystring = "Computer"
print(mystring)
print(mystring[0])  # first character of a string
print(mystring[-1]) # last character of a string
print(mystring[-2]) # second last character of a string

