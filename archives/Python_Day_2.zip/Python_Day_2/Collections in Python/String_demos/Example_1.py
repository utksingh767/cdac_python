# first example of string
# mystring = "hello"
# mystring = 'hello'
mystring = '''hello'''
print(mystring)
print(type(mystring))
print(len(mystring))
# mystring[0]='G'  # Not possible, strings are immutable
