# reverse a string

mystring = input("Enter a string")

print("Before reversing")
print(mystring)

mystring = mystring[::-1]
print(mystring)

