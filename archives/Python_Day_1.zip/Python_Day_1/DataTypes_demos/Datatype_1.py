a=100
print(a)
print("The number is",a)
print("The datatype of a is",type(a))



