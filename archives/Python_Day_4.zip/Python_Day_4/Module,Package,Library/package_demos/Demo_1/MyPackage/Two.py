def disp2():
    print("this is disp2 of Two_py")