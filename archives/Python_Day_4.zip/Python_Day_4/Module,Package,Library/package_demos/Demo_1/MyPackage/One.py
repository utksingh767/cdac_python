def disp1():
    print("this is disp1 of One_py")